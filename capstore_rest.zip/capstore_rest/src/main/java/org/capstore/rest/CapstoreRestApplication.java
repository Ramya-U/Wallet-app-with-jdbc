package org.capstore.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoreRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoreRestApplication.class, args);
	}
}
