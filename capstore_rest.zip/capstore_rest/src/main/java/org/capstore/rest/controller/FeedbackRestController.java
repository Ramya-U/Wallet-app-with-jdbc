package org.capstore.rest.controller;

import java.util.List;

import org.capstore.rest.model.FeedBack;
import org.capstore.rest.service.FeedBack1Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/api/v1")
public class FeedbackRestController {
	
	
        @Autowired
		private FeedBack1Service feedbackService;
		
		@GetMapping("/feedback1")
		public ResponseEntity<List<FeedBack>> getAllFeedback(){
			List<FeedBack> feedback1= feedbackService.getAll();
			if(feedback1.isEmpty()||feedback1==null)
				return new ResponseEntity
						("Sorry! Feedback details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<FeedBack>>(feedback1,HttpStatus.OK);
		}
		
		@PostMapping("/feedback1")
		public ResponseEntity<FeedBack> createFeedback(@RequestBody FeedBack feedback1){
			feedbackService.save(feedback1);
			
			return new ResponseEntity<FeedBack>(feedback1,HttpStatus.OK);
		}
		
	

		
}

