package org.capstore.rest.service;

import java.util.List;
import org.capstore.rest.model.FeedBack;

public interface FeedBack1Service {
	public void save(FeedBack FeedBack);
	public List<FeedBack> getAll();
}
