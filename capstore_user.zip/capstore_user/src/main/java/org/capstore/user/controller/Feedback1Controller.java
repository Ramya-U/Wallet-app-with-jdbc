package org.capstore.user.controller;

import javax.validation.Valid;

import org.capstore.user.model.FeedBack;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class Feedback1Controller {
	
	@RequestMapping("/")
	public String feedbackForm(ModelMap map) {
		
		
		final String uri="http://localhost:8084/capstoreApp/api/v1/feedback1";
		RestTemplate restTemplate=new RestTemplate();
		
		FeedBack[] fd= restTemplate.getForObject(uri, FeedBack[].class);
		
		
		map.put("fd",fd);
		map.put("feedback1", new FeedBack());
		
		return "feedback1Form";
	}
		
		@RequestMapping("/saveComments")
		public String showFeedbackComment(
				@Valid @ModelAttribute("feedback") FeedBack feedback1,@RequestParam("rati")String rati,
				BindingResult result) {
			System.out.println(result);
			if(!result.hasErrors()) {
				
				System.out.println(result);
				Integer rating=Integer.parseInt(rati);
				feedback1.setProductRating(rating);
				final String uri="http://localhost:8084/capstoreApp/api/v1/feedback1";
				RestTemplate restTemplate=new RestTemplate();
				

						restTemplate.postForEntity(uri,feedback1,FeedBack.class);
			
			}
			
			return "redirect:/";

}
	
		
		
	
	

}





