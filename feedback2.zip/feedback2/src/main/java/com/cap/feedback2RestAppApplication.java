package com.cap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class feedback2RestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(feedback2RestAppApplication.class, args);
	}
}
