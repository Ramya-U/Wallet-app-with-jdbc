package com.cap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Feedback2AppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Feedback2AppApplication.class, args);
	}
}
