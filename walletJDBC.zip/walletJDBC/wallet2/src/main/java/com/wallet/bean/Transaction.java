package com.wallet.bean;

import java.sql.Date;

public class Transaction {
	private int tid;
	private String ttype;
	private Date tDate;
	private double amt;
	
	private int accNo;

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getTtype() {
		return ttype;
	}

	public void setTtype(String ttype) {
		this.ttype = ttype;
	}

	public Date gettDate() {
		return tDate;
	}

	public void settDate(Date tDate) {
		this.tDate = tDate;
	}

	public double getAmt() {
		return amt;
	}

	public void setAmt(double amt) {
		this.amt = amt;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	@Override
	public String toString() {
		return "Transaction [tid=" + tid + ", ttype=" + ttype + ", tDate=" + tDate + ", amt=" + amt + ", accNo=" + accNo
				+ "]";
	}

	public Transaction(int tid, String ttype, Date tDate, double amt, int accNo) {
		super();
		this.tid = tid;
		this.ttype = ttype;
		this.tDate = tDate;
		this.amt = amt;
		this.accNo = accNo;
	}
	
	public Transaction(){
		
	}

	
}
