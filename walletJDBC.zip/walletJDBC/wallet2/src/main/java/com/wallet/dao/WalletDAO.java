package com.wallet.dao;


import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public interface WalletDAO {
	Integer createAccount(Customer request)throws WalletException;
	public double showBalance (Integer accountNo) throws WalletException;
	double deposit(double b1, Integer getAccountNo)throws WalletException;
	double withdraw(double b1, Integer getAccountNo)throws WalletException;
	public boolean printTransaction(int accno) throws WalletException;
}

